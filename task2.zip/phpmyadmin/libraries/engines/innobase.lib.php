<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @package PhpMyAdmin-Engines
 */
if (! defined('PHPMYADMIN')) {
    exit;
}

/**
 *
 */
require_once './libraries/engines/innodb.lib.php';

/**
 *
 * @package PhpMyAdmin-Engines
 */
class PMA_StorageEngine_innobase extends PMA_StorageEngine_innodb
{
}
?>
