<?php
$db = mysql_connect ("localhost","user","1234");
mysql_select_db ("mysql",$db);
?>