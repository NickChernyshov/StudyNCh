<?php
if (empty($_GET['page'])) {
    $page = 1;
} else {
    $page = (int)$_GET['page'];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.1 Transitional//ENG">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>First page NCh</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>
<body>
<?php
if ($page == 1) {
    include_once("templates/header_p1.html");
} else {
    include_once("templates/header.html");
}
?>
<div id="menu">
    <div class="fixed">
        <ul class="ul_none">
            <li><a href="/index.php?page=1" class="menu" title="Main">General</a></li>
            <li><a href="/index.php?page=2" class="menu" title="About">About</a></li>
            <li><a href="?page=3" class="menu" title="Contact">Contact info</a></li>
        </ul>
    </div>
</div>
<div id="content">
    <?php
    if ($page == 1) {
        include("pages/1.html");
    } else {
        if ($page == 2) {
            include("pages/2.html");
        } else {
            include("pages/3.html");
        }
    }
    ?>
</div>
<?php
include_once('templates/footer.html');
?>
</body>
</html>